module.exports = {
    apps : [{
      name      : 'Condoriano',
      script    : './index.js',
      node_args : '-r dotenv/config',
    }],
  }